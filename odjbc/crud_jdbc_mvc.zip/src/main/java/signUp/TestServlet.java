package signUp;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		MemberVO member01 = new MemberVO("testhong1", "4444", "홍길동", "rename1@gmail.com", null);
//		MemberVO member02 = new MemberVO("testhong2", "1234", "홍길동동", "test2@gmail.com", null);
//		MemberVO member03 = new MemberVO("testhong3", "1234", "홍길동길", "test3@gmail.com", null);
//		
		MemberDAO memberDAO = new MemberDAO();
		
		
//		
		memberDAO.updateMember(member01);
//		memberDAO.newMember(member02);
//		memberDAO.newMember(member03);
//		
//		//
//		System.out.println("-----");
//		memberDAO.getMember("testhong1");
//		//
//		System.out.println("-----");
//		memberDAO.getMembers();
		
//		memberDAO.deleteMemeber("testhong1");
	}

	
	
}
