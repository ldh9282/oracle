package signUp;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dbUtil.DBUtil;

public class MemberDAO {
	private static final String ConnPoolName = "jdbc/myuser";
	
	public MemberVO getMember(String tempMid) {
		MemberVO member = null;
		
		String sql = "SELECT * FROM MYUSER.TBL_MEMBER WHERE MID = ?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection(ConnPoolName);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, tempMid);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String mid = rs.getString("mid");
				String mpassword = rs.getString("mpassword");
				String mname = rs.getString("mname");
				String memail = rs.getString("memail");
				Date mjoinDate = rs.getDate("mjoindate");
				
				member = new MemberVO(mid, mpassword, mname, memail, mjoinDate);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		// console test 
		System.out.println("member: " + member);
		return member;
	}
	public List<MemberVO> getMembers() {
		List<MemberVO> members = new ArrayList<>();
		
		String sql = "SELECT * FROM MYUSER.TBL_MEMBER";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection(ConnPoolName);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String mid = rs.getString("mid");
				String mpassword = rs.getString("mpassword");
				String mname = rs.getString("mname");
				String memail = rs.getString("memail");
				Date mjoinDate = rs.getDate("mjoindate");
				
				MemberVO member = new MemberVO(mid, mpassword, mname, memail, mjoinDate);
				members.add(member);
			}
			
			DBUtil.close(rs, pstmt, conn);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			DBUtil.close(rs, pstmt, conn);
		}
		
		// console test 
		for (MemberVO memberVO : members) {
			System.out.println("getMembers: " + memberVO);
		}
		return members;
	}
	
	public void newMember(MemberVO member) {
		
		String sql = "INSERT INTO MYUSER.TBL_MEMBER VALUES (?, ?, ?, ?, SYSDATE)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection(ConnPoolName);
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, member.getMid());
			pstmt.setString(2, member.getMpassword());
			pstmt.setString(3, member.getMname());
			pstmt.setString(4, member.getMemail());
			
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, pstmt, conn);
		}
		
		// console test 
		System.out.println("nemMeber: " + member);
	}

	public void deleteMemeber(String mid) {
		String sql = "DELETE FROM MYUSER.TBL_MEMBER WHERE MID = ?";
		// consloe test
		System.out.println("deleteMember( "+  mid + " -> ?): " + sql);
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection(ConnPoolName);
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, mid);
			
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, pstmt, conn);
		}
	}
	public void updateMember(MemberVO member) {
		String mid = member.getMid();
		String mpassword = member.getMpassword();
		String memail = member.getMemail();
		String sql = "UPDATE MYUSER.TBL_MEMBER SET MPASSWORD = ?, memail = ? WHERE MID = ?"; 
		
		
		// console test
		System.out.println("(mid, mpassword, memail): (" + mid + ", " + mpassword + ", " + memail + ") -> "+ sql);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection(ConnPoolName);
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, mpassword);
			pstmt.setString(2, memail);
			pstmt.setString(3, mid);
			
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(null, pstmt, conn);
		}
				
		
		
	}
}
