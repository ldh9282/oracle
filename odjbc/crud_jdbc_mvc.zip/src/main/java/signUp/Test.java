package signUp;

public class Test {

	public static void main(String[] args) {

		MemberVO member01 = new MemberVO("testhong1", "1234", "홍길동", "test1@gmail.com", null);
		MemberVO member02 = new MemberVO("testhong2", "1234", "홍길동동", "test2@gmail.com", null);
		MemberVO member03 = new MemberVO("testhong3", "1234", "홍길동길", "test3@gmail.com", null);
		
		MemberDAO memberDAO = new MemberDAO();
		
		
		
		memberDAO.newMember(member01);
		memberDAO.newMember(member02);
		memberDAO.newMember(member03);
		
		//
		System.out.println("-----");
		memberDAO.getMember("testhong1");
		//
		System.out.println("-----");
		memberDAO.getMembers();
	}

}
